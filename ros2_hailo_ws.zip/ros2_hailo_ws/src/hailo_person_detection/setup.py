from setuptools import find_packages, setup

package_name = 'hailo_person_detection'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='raspespion',
    maintainer_email='raspespion@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
	    'camera_publisher = hailo_person_detection.camera_publisher:main',
	    'hailo_inference = hailo_person_detection.hailo_inference:main', 
        ],
    },
)
