import os
os.environ["OPENCV_FFMPEG_CAPTURE_OPTIONS"] = "rtsp_transport;udp"

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import CompressedImage
import cv2
import threading
import time


class CameraPublisher(Node):
    def __init__(self):
        super().__init__('camera_publisher')
        self.publisher_ = self.create_publisher(CompressedImage, '/camera/image/compressed', 10)
        
        # URL de votre caméra IP (À ajuster avec vos identifiants/IP)
        self.rtsp_url = "rtsp://admin:123456@192.168.6.200:554/h264Preview_01_main"
        
        self.get_logger().info("Connexion à la caméra IP")
        self.cap = cv2.VideoCapture(self.rtsp_url, cv2.CAP_FFMPEG)
        
        if not self.cap.isOpened():
            self.get_logger().error("Impossible de se connecter à la caméra IP ")
            return
            
        self.latest_frame = None
        self.ret = False
        self.running = True
        
        # CORRECTIF 2 : Création d'un Thread indépendant pour lire le flux vidéo
        self.capture_thread = threading.Thread(target=self.update_frame_buffer)
        self.capture_thread.daemon = True
        self.capture_thread.start()

        # Timer ROS 2 pour publier les images à l'IA (0.033s = ~30 FPS)
        self.timer = self.create_timer(0.033, self.timer_callback)
        self.get_logger().info("Flux caméra IP stabilisé et prêt.")

    def update_frame_buffer(self):
        """ Boucle de lecture isolée dans un thread pour ne jamais perdre de paquets """
        while self.running:
            if self.cap.isOpened():
                ret, frame = self.cap.read()
                if ret:
                    self.latest_frame = frame
                    self.ret = True
                else:
                    self.ret = False
            time.sleep(0.005) # Pause microscopique pour relâcher le CPU

    def timer_callback(self):
        """ Le timer ROS 2 vient simplement piocher la dernière image disponible """
        if self.ret and self.latest_frame is not None:
            # Copie rapide de l'image pour éviter les conflits entre threads
            frame = self.latest_frame.copy()
            
            # Redimensionnement léger (idéal pour l'inférence YOLO du Hailo)
            frame = cv2.resize(frame, (640, 480))
            
            # Encodage JPEG avec une qualité de 80% pour alléger le réseau ROS 2
            success, encoded_image = cv2.imencode('.jpg', frame, [cv2.IMWRITE_JPEG_QUALITY, 80])
            
            if success:
                msg = CompressedImage()
                msg.header.stamp = self.get_clock().now().to_msg()
                msg.format = "jpeg"
                msg.data = encoded_image.tobytes()
                self.publisher_.publish(msg)
        else:
            # Ce warning est bridé pour s'afficher au maximum toutes les 3 secondes au lieu de spammer
            self.get_logger().warning("En attente d'un flux d'images stable...", throttle_duration_sec=3.0)

    def destroy_node(self):
        self.running = False
        self.capture_thread.join(timeout=1.0)
        if self.cap.isOpened():
            self.cap.release()
        super().destroy_node()

def main(args=None):
    rclpy.init(args=args)
    node = CameraPublisher()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
