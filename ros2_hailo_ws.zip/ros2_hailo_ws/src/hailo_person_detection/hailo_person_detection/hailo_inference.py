import rclpy
from rclpy.node import Node
from sensor_msgs.msg import CompressedImage
import cv2
import numpy as np
from hailo_platform import (HEF, Device, ConfigureParams, 
                            InputVStreamParams, OutputVStreamParams, InferVStreams)

class HailoInferenceNode(Node):
    def __init__(self):
        super().__init__('hailo_inference_node')
        
        self.subscription = self.create_subscription(CompressedImage, '/camera/image/compressed', self.image_callback, 10)
        self.publisher_ = self.create_publisher(CompressedImage, '/yolo/annotated_image', 10)
        
        from hailo_platform import VDevice
        self.target = VDevice()
        self.hef = HEF('/home/raspespion/yolov8n.hef') 
        
        from hailo_platform import HailoStreamInterface
        self.configure_params = ConfigureParams.create_from_hef(self.hef, interface=HailoStreamInterface.PCIe)
        
        self.network_group = self.target.configure(self.hef, self.configure_params)[0]
        
        from hailo_platform import InputVStreamParams, OutputVStreamParams
        self.input_vstreams_params = InputVStreamParams.make_from_network_group(self.network_group)
        self.output_vstreams_params = OutputVStreamParams.make_from_network_group(self.network_group)
        
        self.infer_pipeline = None

    def image_callback(self, msg):
        # 1. Conversion de l'image ROS compressée en OpenCV BGR
        np_arr = np.frombuffer(msg.data, np.uint8)
        frame = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
        if frame is None:
            return

        h, w, _ = frame.shape

        # 2. Prétraitement pour YOLOv8 (640x640, BGR vers RGB)
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        frame_resized = cv2.resize(frame_rgb, (640, 640))
        frame_final = np.expand_dims(frame_resized, axis=0)

        vstream_name = self.network_group.get_input_vstream_infos()[0].name

        # 3. Exécution de l'inférence via le pipeline actif
        try:
            if self.infer_pipeline is None:
                return
            
            infer_results = self.infer_pipeline.infer({vstream_name: frame_final})
            
            # 4. Parsing et décodage de la sortie NMS intégrée de Hailo
            for name, tensor in infer_results.items():
                if 'nms' in name.lower():
                    # Le tenseur principal est une liste de taille 'batch_size' (ici 1)
                    if isinstance(tensor, (list, tuple)) and len(tensor) > 0:
                        nms_data = tensor[0] # Contenu de notre image (c'est une liste d'après le log)
                        
                        if isinstance(nms_data, list):
                            # --- CAS A : Format Hailo NMS par classe (Ex: une liste de 80 éléments pour COCO) ---
                            if len(nms_data) > 4:
                                for class_id, class_tensor in enumerate(nms_data):
                                    if hasattr(class_tensor, 'shape') and len(class_tensor.shape) == 2:
                                        # Chaque classe_tensor a la forme (N, 5) -> [ymin, xmin, ymax, xmax, score]
                                        for detection in class_tensor:
                                            score = float(detection[4])
                                            if score > 0.3: # Seuil de confiance à 30%
                                                ymin, xmin, ymax, xmax = detection[:4]
                                                
                                                # Conversion des coordonnées normalisées (0-1) vers les pixels originaux
                                                x1 = int(xmin * w)
                                                y1 = int(ymin * h)
                                                x2 = int(xmax * w)
                                                y2 = int(ymax * h)
                                                
                                                # Dessin de la boîte et du label
                                                cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
                                                cv2.putText(frame, f"Class {class_id}: {score:.2f}", (x1, y1 - 10),
                                                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
                            
                            # --- CAS B : Format ordonné global (3 ou 4 tenseurs globaux : [boxes, scores, classes]) ---
                            elif len(nms_data) in [3, 4]:
                                boxes = nms_data[0]
                                scores = nms_data[1]
                                classes = nms_data[2]
                                
                                for i in range(len(scores)):
                                    score = float(scores[i])
                                    if score > 0.3:
                                        class_id = int(classes[i])
                                        ymin, xmin, ymax, xmax = boxes[i]
                                        
                                        x1 = int(xmin * w)
                                        y1 = int(ymin * h)
                                        x2 = int(xmax * w)
                                        y2 = int(ymax * h)
                                        
                                        cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
                                        cv2.putText(frame, f"Class {class_id}: {score:.2f}", (x1, y1 - 10),
                                                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
            
            # 5. Affichage de la fenêtre vidéo en direct
            cv2.imshow("YOLO Hailo-8 Live", frame)
            cv2.waitKey(1)
            
            # 6. Publication de la version annotée sur ROS 2
            _, buffer = cv2.imencode('.jpg', frame)
            msg_out = CompressedImage()
            msg_out.header = msg.header
            msg_out.format = "jpeg"
            msg_out.data = buffer.tobytes()
            self.publisher_.publish(msg_out)
            
        except Exception as e:
            self.get_logger().error(f"Erreur d'inférence : {e}")

def main(args=None):
    rclpy.init(args=args)
    node = HailoInferenceNode()

    node.get_logger().info("Allumage et configuration de la puce Hailo-8...")
    
    with node.network_group.activate():
        with InferVStreams(node.network_group, node.input_vstreams_params, node.output_vstreams_params) as infer_pipeline:
            node.infer_pipeline = infer_pipeline
            node.get_logger().info("🚀 Hailo-8 prête ! Traitement du flux en cours...")
            rclpy.spin(node)

if __name__ == '__main__':
    main()
